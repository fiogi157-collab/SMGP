import i18n from "i18next"
import { initReactI18next } from "react-i18next"
import LanguageDetector from "i18next-browser-languagedetector"

export const resources = {
  FR: {
    translation: {
      welcome: "Bienvenue sur Sweetmoon Brand Builder",
      login: "Se connecter",
      logout: "Se déconnecter",
      email: "Email",
      password: "Mot de passe",
      dashboard: "Tableau de bord",
      products: "Produits",
      orders: "Commandes",
      brands: "Marques"
    }
  },
  EN: {
    translation: {
      welcome: "Welcome to Sweetmoon Brand Builder",
      login: "Sign in",
      logout: "Sign out",
      email: "Email",
      password: "Password",
      dashboard: "Dashboard",
      products: "Products",
      orders: "Orders",
      brands: "Brands"
    }
  },
  AR: {
    translation: {
      welcome: "مرحباً بكم في منصة سويت مون لبناء العلامات",
      login: "تسجيل الدخول",
      logout: "تسجيل الخروج",
      email: "البريد الإلكتروني",
      password: "كلمة المرور",
      dashboard: "لوحة التحكم",
      products: "المنتجات",
      orders: "الطلبات",
      brands: "العلامات"
    }
  }
}

if (!i18n.isInitialized) {
  i18n
    .use(LanguageDetector as any)
    .use(initReactI18next)
    .init({
      resources,
      fallbackLng: "FR",
      interpolation: { escapeValue: false },
      detection: {
        order: ['querystring', 'cookie', 'localStorage', 'navigator'],
        caches: ['localStorage', 'cookie']
      }
    })
}

export default i18n
