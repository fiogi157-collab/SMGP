'use server'
import { dbConnect } from "./db"
import { User } from "@/models/User"
import argon2 from "argon2"

export async function ensureAdmin() {
  await dbConnect()
  const email = process.env.ADMIN_EMAIL || "admin@sweetmoon.shop"
  const pwd = process.env.ADMIN_PASSWORD || "Sweetmoon2025"
  let user = await User.findOne({ email })
  if (!user) {
    const hash = await argon2.hash(pwd)
    user = await User.create({ email, password: hash, role: 'admin' })
  }
  return { email: user.email }
}
