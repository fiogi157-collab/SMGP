import ProductsTable from "./table"

export default function ProductsPage() {
  return (
    <div className="glass p-6">
      <h1 className="text-2xl font-semibold mb-4">Produits</h1>
      <ProductsTable />
    </div>
  )
}
