'use client'
import useSWR from "swr"
const fetcher = (url:string)=>fetch(url).then(r=>r.json())

export default function ProductsTable(){
  const { data, mutate } = useSWR('/api/products', fetcher)
  async function remove(id:string){
    await fetch('/api/products/'+id, { method: 'DELETE' })
    mutate()
  }
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full text-sm">
        <thead><tr><th className="text-left p-2">Nom</th><th>Prix</th><th>Stock</th><th></th></tr></thead>
        <tbody>
          {data?.products?.map((p:any)=>(
            <tr key={p._id} className="border-t">
              <td className="p-2">{p.name}</td>
              <td className="text-center">{p.price.toFixed(2)} €</td>
              <td className="text-center">{p.stock}</td>
              <td className="text-right p-2">
                <button onClick={()=>remove(p._id)} className="text-red-600">Supprimer</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
