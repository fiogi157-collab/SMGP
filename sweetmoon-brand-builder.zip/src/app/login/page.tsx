'use client'
import { useState, FormEvent } from "react"
import { signIn } from "next-auth/react"
import { useRouter } from "next/navigation"

export default function LoginPage() {
  const [email,setEmail] = useState("")
  const [password,setPassword] = useState("")
  const [error,setError] = useState<string|null>(null)
  const router = useRouter()

  async function onSubmit(e: FormEvent) {
    e.preventDefault()
    const res = await signIn("credentials", { redirect: false, email, password })
    if (res?.error) setError("Identifiants invalides")
    else router.push("/dashboard")
  }

  return (
    <div className="max-w-sm mx-auto glass p-6 mt-10">
      <h1 className="text-2xl font-semibold mb-4">Connexion</h1>
      <form onSubmit={onSubmit} className="space-y-3">
        <input className="w-full border rounded-xl px-3 py-2" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
        <input type="password" className="w-full border rounded-xl px-3 py-2" placeholder="Mot de passe" value={password} onChange={e=>setPassword(e.target.value)} />
        {error && <p className="text-red-600 text-sm">{error}</p>}
        <button className="w-full bg-primary text-white rounded-xl py-2">Se connecter</button>
      </form>
    </div>
  )
}
