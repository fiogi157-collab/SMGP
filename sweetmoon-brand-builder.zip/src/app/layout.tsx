import "./globals.css"
import { ReactNode } from "react"
import { Inter } from "next/font/google"
import { I18nextProvider } from "react-i18next"
import i18n from "@/lib/i18n"
import Link from "next/link"

const inter = Inter({ subsets: ["latin"] })

export const metadata = {
  title: "Sweetmoon Brand Builder",
  description: "SaaS de création de marques de compléments"
}

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fr">
      <body className={inter.className + " min-h-screen"}>
        <I18nextProvider i18n={i18n}>
          <header className="sticky top-0 z-50 backdrop-blur-md bg-white/60 border-b">
            <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
              <Link href="/" className="font-bold text-xl text-primary">Sweetmoon</Link>
              <nav className="flex gap-4 text-sm">
                <Link href="/dashboard" className="hover:underline">Dashboard</Link>
                <Link href="/products" className="hover:underline">Produits</Link>
                <Link href="/orders" className="hover:underline">Commandes</Link>
                <Link href="/brands" className="hover:underline">Marques</Link>
                <Link href="/login" className="hover:underline">Login</Link>
              </nav>
            </div>
          </header>
          <main className="max-w-6xl mx-auto p-4">{children}</main>
          <footer className="text-center py-6 text-xs text-gray-500">© {new Date().getFullYear()} Sweetmoon Labs</footer>
        </I18nextProvider>
      </body>
    </html>
  )
}
