import OrdersTable from "./table"
export default function OrdersPage(){
  return (
    <div className="glass p-6">
      <h1 className="text-2xl font-semibold mb-4">Commandes</h1>
      <OrdersTable />
    </div>
  )
}
