'use client'
import useSWR from "swr"
const fetcher = (u:string)=>fetch(u).then(r=>r.json())

export default function OrdersTable(){
  const { data } = useSWR('/api/orders', fetcher)
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full text-sm">
        <thead><tr><th className="text-left p-2">#</th><th>Statut</th><th>Articles</th><th>Date</th></tr></thead>
        <tbody>
          {data?.orders?.map((o:any,i:number)=>(
            <tr key={o._id} className="border-t">
              <td className="p-2">{i+1}</td>
              <td className="text-center">{o.status}</td>
              <td className="text-center">{o.products.reduce((a:any,c:any)=>a+c.quantity,0)}</td>
              <td className="text-center">{new Date(o.createdAt).toLocaleDateString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
