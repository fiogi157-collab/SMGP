import { ensureAdmin } from "@/lib/seed-admin"
import DashboardClient from "./ui"

export const dynamic = 'force-dynamic'

export default async function DashboardPage() {
  await ensureAdmin()
  return <DashboardClient />
}
