'use client'
import { useMemo } from "react"
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts"

const data = [
  { name: 'Jan', orders: 40 },
  { name: 'Feb', orders: 55 },
  { name: 'Mar', orders: 32 },
  { name: 'Apr', orders: 77 },
  { name: 'May', orders: 61 },
  { name: 'Jun', orders: 90 }
]

export default function DashboardClient() {
  const chartData = useMemo(()=>data,[])
  return (
    <div className="grid lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2 glass p-6">
        <h2 className="text-xl font-semibold mb-4">Commandes (6 mois)</h2>
        <div style={{width:'100%',height:260}}>
          <ResponsiveContainer>
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="c" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopOpacity={0.6}/>
                  <stop offset="95%" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Area type="monotone" dataKey="orders" strokeWidth={2} fillOpacity={1} fill="url(#c)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
      <div className="glass p-6">
        <h2 className="text-xl font-semibold mb-4">Statistiques</h2>
        <ul className="space-y-2">
          <li>Total commandes: <strong>355</strong></li>
          <li>En cours: <strong>18</strong></li>
          <li>Livrées: <strong>296</strong></li>
          <li>Annulées: <strong>41</strong></li>
        </ul>
      </div>
    </div>
  )
}
