import { NextRequest, NextResponse } from "next/server"
import { dbConnect } from "@/lib/db"
import { Brand } from "@/models/Brand"

export async function GET() {
  await dbConnect()
  const brands = await Brand.find().populate('customizedProducts')
  return NextResponse.json({ brands })
}

export async function POST(req: NextRequest){
  const body = await req.json()
  await dbConnect()
  const brand = await Brand.create(body)
  return NextResponse.json({ brand })
}
