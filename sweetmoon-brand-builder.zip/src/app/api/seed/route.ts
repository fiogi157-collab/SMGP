import { NextResponse } from "next/server"
import { dbConnect } from "@/lib/db"
import { Product } from "@/models/Product"

export async function GET(){
  await dbConnect()
  const count = await Product.countDocuments()
  if (count === 0){
    await Product.insertMany([
      { name: "Collagène Marin", price: 12.99, description: "Beauté de la peau, ongles et cheveux.", stock: 100 },
      { name: "Vitamine C 1000mg", price: 9.99, description: "Immunité et énergie.", stock: 200 },
      { name: "Oméga 3", price: 14.99, description: "Santé du cœur et du cerveau.", stock: 150 },
      { name: "Ashwagandha Bio", price: 15.49, description: "Anti-stress naturel.", stock: 120 },
      { name: "Zinc", price: 8.99, description: "Peau, cheveux, immunité.", stock: 180 }
    ])
  }
  return NextResponse.json({ ok: true })
}
