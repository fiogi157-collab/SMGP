import { NextResponse } from "next/server"
import { dbConnect } from "@/lib/db"
import { Product } from "@/models/Product"

export async function DELETE(_: Request, { params }: { params: { id: string } }) {
  await dbConnect()
  await Product.findByIdAndDelete(params.id)
  return NextResponse.json({ ok: true })
}
