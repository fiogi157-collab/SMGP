import { NextRequest, NextResponse } from "next/server"
import { dbConnect } from "@/lib/db"
import { Product } from "@/models/Product"

export async function GET() {
  await dbConnect()
  const products = await Product.find().sort({createdAt:-1})
  return NextResponse.json({ products })
}

export async function POST(req: NextRequest) {
  const body = await req.json()
  await dbConnect()
  const p = await Product.create(body)
  return NextResponse.json({ product: p })
}
