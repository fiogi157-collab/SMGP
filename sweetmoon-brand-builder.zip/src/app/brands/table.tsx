'use client'
import useSWR from "swr"
const fetcher = (u:string)=>fetch(u).then(r=>r.json())

export default function BrandsTable(){
  const { data } = useSWR('/api/brands', fetcher)
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full text-sm">
        <thead><tr><th className="text-left p-2">Nom</th><th>Email</th><th>Produits personnalisés</th></tr></thead>
        <tbody>
          {data?.brands?.map((b:any)=>(
            <tr key={b._id} className="border-t">
              <td className="p-2">{b.name}</td>
              <td className="text-center">{b.email}</td>
              <td className="text-center">{b.customizedProducts?.length || 0}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
