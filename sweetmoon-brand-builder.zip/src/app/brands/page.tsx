import BrandsTable from "./table"
export default function BrandsPage(){
  return (
    <div className="glass p-6">
      <h1 className="text-2xl font-semibold mb-4">Marques</h1>
      <BrandsTable />
    </div>
  )
}
