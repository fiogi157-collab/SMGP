'use client'
import { useTranslation } from "react-i18next"
import { motion } from "framer-motion"
import Link from "next/link"

export default function HomePage() {
  const { t, i18n } = useTranslation()
  return (
    <div className="grid md:grid-cols-2 gap-6 items-center">
      <motion.div initial={{opacity:0,y:8}} animate={{opacity:1,y:0}} transition={{duration:.5}} className="glass p-8">
        <h1 className="text-3xl font-bold mb-2">{t('welcome')}</h1>
        <p className="text-gray-600 mb-4">
          Plateforme pour créer et gérer vos gélules sous marque propre. Personnalisez l’étiquette, suivez les commandes, et pilotez la logistique.
        </p>
        <div className="flex gap-3">
          <Link href="/dashboard" className="px-4 py-2 rounded-xl bg-primary text-white">Accéder au Dashboard</Link>
          <button onClick={()=>i18n.changeLanguage('FR')} className="px-3 py-2 border rounded-xl">FR</button>
          <button onClick={()=>i18n.changeLanguage('EN')} className="px-3 py-2 border rounded-xl">EN</button>
          <button onClick={()=>i18n.changeLanguage('AR')} className="px-3 py-2 border rounded-xl">AR</button>
        </div>
      </motion.div>
      <motion.div initial={{opacity:0,scale:.97}} animate={{opacity:1,scale:1}} transition={{duration:.6, delay:.1}} className="glass p-8">
        <h2 className="text-xl font-semibold mb-3">Fonctionnalités clés</h2>
        <ul className="space-y-2 list-disc pl-5 text-gray-700">
          <li>Catalogue produits personnalisables</li>
          <li>Commandes & suivi livraison</li>
          <li>Statistiques en temps réel</li>
          <li>Rôles: admin / brand / delivery</li>
        </ul>
      </motion.div>
    </div>
  )
}
