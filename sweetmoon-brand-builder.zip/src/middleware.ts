import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export function middleware(req: NextRequest) {
  // demo: protect /admin with a naive check; in real app parse session/jwt on server
  if (req.nextUrl.pathname.startsWith('/admin')) {
    // Allow; NextAuth route-level checks will occur in components
  }
  return NextResponse.next()
}
