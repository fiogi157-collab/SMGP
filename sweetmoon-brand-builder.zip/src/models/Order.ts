import { Schema, model, models, Types } from "mongoose"

const OrderSchema = new Schema({
  brandId: { type: Types.ObjectId, ref: 'Brand', required: true },
  products: [{
    productId: { type: Types.ObjectId, ref: 'Product', required: true },
    quantity: { type: Number, required: true, min: 1 }
  }],
  status: { type: String, enum: ['pending','processing','shipped','delivered','cancelled'], default: 'pending' },
  createdAt: { type: Date, default: Date.now }
})

export const Order = models.Order || model('Order', OrderSchema)
