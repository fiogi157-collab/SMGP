import { Schema, model, models, Types } from "mongoose"

const BrandSchema = new Schema({
  name: { type: String, required: true },
  logo: { type: String },
  email: { type: String, required: true },
  customizedProducts: [{ type: Types.ObjectId, ref: 'Product' }],
  createdAt: { type: Date, default: Date.now }
})

export const Brand = models.Brand || model('Brand', BrandSchema)
