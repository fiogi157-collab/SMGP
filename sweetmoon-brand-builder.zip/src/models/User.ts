import { Schema, model, models } from "mongoose"

export type Role = 'admin' | 'brand' | 'delivery'

const UserSchema = new Schema({
  email: { type: String, unique: true, required: true },
  password: { type: String, required: true },
  role: { type: String, enum: ['admin','brand','delivery'], default: 'brand' }
}, { timestamps: true })

export const User = models.User || model('User', UserSchema)
